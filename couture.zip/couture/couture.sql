-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 01 avr. 2021 à 07:06
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `couture`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id_article` int(11) NOT NULL,
  `type_article` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `type_article`) VALUES
(1, 'robe'),
(2, 'ensemble_tailleure'),
(3, 'combinaison'),
(4, 'traditionnelle_dan');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `id_register` text NOT NULL,
  `code_commande` varchar(255) NOT NULL,
  `article` varchar(255) NOT NULL,
  `prix` int(255) NOT NULL,
  `quantité` int(20) NOT NULL,
  `statut` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `id_register`, `code_commande`, `article`, `prix`, `quantité`, `statut`, `date`) VALUES
(1, '7', '3456', 'costube', 0, 0, 'En Attente', '0000-00-00'),
(2, '4', '7457', 'robe', 0, 1, 'En Attente', '0000-00-00'),
(3, '2', '9567', 'm00k', 0, 3, 'En Attente', '2021-03-21'),
(4, '2', '48779', 'DFGH', 0, 2, 'En Attente', '2021-03-17'),
(11, '4', 'comlk9617', 'robe', 20000, 2, 'En cour', '0000-00-00'),
(17, '7', 'comlk44939', 'mo0', 20000, 2, 'En cour', '2021-03-30'),
(68, '4', 'dfghh45', 'ensemble tailleur', 0, 0, 'En cour', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `mensuration`
--

CREATE TABLE `mensuration` (
  `id_mensuration` int(11) NOT NULL,
  `id_register` int(11) NOT NULL,
  `taille` double NOT NULL,
  `epaule` double NOT NULL,
  `tour_de_taille` double NOT NULL,
  `poitrine` double NOT NULL,
  `manche` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `mensuration`
--

INSERT INTO `mensuration` (`id_mensuration`, `id_register`, `taille`, `epaule`, `tour_de_taille`, `poitrine`, `manche`) VALUES
(1, 1, 1.6, 45, 43, 65, 32),
(2, 3, 9, 9, 9, 9, 9),
(3, 2, 1.74, 64, 43, 63, 24),
(22, 7, 2, 2, 2, 2, 2),
(64, 6, 12, 13, 12, 13, 13),
(72, 4, 15, 12, 21, 10, 11),
(73, 5, 10, 14, 21, 4, 19);

-- --------------------------------------------------------

--
-- Structure de la table `register`
--

CREATE TABLE `register` (
  `id_register` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `prenom` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `hash` varchar(200) NOT NULL,
  `salt` varchar(50) NOT NULL,
  `ville` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `register`
--

INSERT INTO `register` (`id_register`, `nom`, `prenom`, `email`, `numero`, `hash`, `salt`, `ville`) VALUES
(1, 'appia', 'appia', 'appia', 'monk', '$5$rounds=5000$somheashchappia$bP4ViAIOJCnAi3y6svLufrrR2nzKmN1hG2zbig5EBg6', '$5$rounds=5000$somheashchappia$', 'appia'),
(2, 'marco', 'marco', 'marco', '5699885', '$5$rounds=5000$somheashchmarco$V.r9GMpg0iXxPZAEfvgu9Zjeab.epvbv9Bt175j9upD', '$5$rounds=5000$somheashchmarco$', 'marco'),
(3, 'kiwi', 'felix', 'felix@gmail.com', '4444444', '$5$rounds=5000$somheashchkiwi$ZyFgvX9dCT.5Wq8m.ORjpZ5mEeODoANUNv.tfBrbg62', '$5$rounds=5000$somheashchkiwi$', 'Aboisso'),
(4, 'elie', 'elie', 'elie', '9663333', '$5$rounds=5000$somheashchelie$oeKNn2JclMKoyqWgYNkQhdWlosIT1ReyVuUd4J5e024', '$5$rounds=5000$somheashchelie$', 'elie'),
(5, 'milka', 'milka', 'milka', '44621834', '', '', ''),
(6, 'aka', 'pierre', 'pierre@gmail.com', '101010', '$5$rounds=5000$somheashchaka$c8cBxkg/VhIJOcloPJ09swbAjhTEGNBYNhi3KO.cG24', '$5$rounds=5000$somheashchaka$', 'Abidjan'),
(7, 'kwamé', 'jean', 'kwame@gmail.com', '48202020', '$5$rounds=5000$somheashchkwamé$92HERO2OzFLhDgyV.gh/vUDqI.VZL3toqB.hPG4yqJC', '$5$rounds=5000$somheashchkwamé$', 'Abidjan');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`);

--
-- Index pour la table `mensuration`
--
ALTER TABLE `mensuration`
  ADD PRIMARY KEY (`id_mensuration`);

--
-- Index pour la table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id_register`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT pour la table `mensuration`
--
ALTER TABLE `mensuration`
  MODIFY `id_mensuration` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT pour la table `register`
--
ALTER TABLE `register`
  MODIFY `id_register` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
