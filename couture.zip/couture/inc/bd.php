<?php

/* $conn= new PDO("mysql:host=localhost; dbname=couture",'root','');*/

 try{
 	$conn= new PDO("mysql:host=localhost; dbname=couture",'root','');
 }catch(PDOException $e){
 	die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 }
 
 ?>

<?php

//build the connection variable and assign database credentials
$connect = mysqli_connect('localhost','root','','couture');

//if DB connection fails, get a error message
if(!$connect){
    die('Connection Failed'.mysqli_connect_error());
}

?>
