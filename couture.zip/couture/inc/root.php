
<?php 
// chemin vers les differents fichier et dossier dashboard
// home.php
$root='assets/dashboard/';

// header.php
$css='assets/css/';

// view/infos_commande.php
$root_img='assets/files/';

// view/sigin.php
$root_signin='assets/signin/';
?>

