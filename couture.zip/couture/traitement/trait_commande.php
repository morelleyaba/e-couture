<?php  
 if(isset($_POST["commande_value"]))  
 {  
      $output = '';  
    include('../inc/bd.php');


      $querys = "SELECT id_register,code_commande FROM commande WHERE code_commande = '".$_POST["commande_value"]."'";  
      // 
      $results = mysqli_query($connect, $querys); 
      $key = $results->fetch_assoc();
      $id_register=$key["id_register"];
      $code_commande=$key["code_commande"];
      // var_dump($key["id_register"]);

      $query = "SELECT * FROM mensuration WHERE id_register = '{$id_register}'";  
      // 

      $result = mysqli_query($connect, $query);  
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '  
                    <label>Code commande  :  '.$code_commande.'</label> 
                <br>
                <br>  
                     <label>MENSURATIONS</label>  
                </tr>
                <tr>  
                     <td width="30%"><label>Taille</label></td>  
                     <td width="70%">'.$row["taille"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Epaule</label></td>  
                     <td width="70%">'.$row["epaule"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Tour de Taille</label></td>  
                     <td width="70%">'.$row["tour_de_taille"].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Poitrine</label></td>  
                     <td width="70%">'.$row["poitrine"].' </td>  
                </tr>  
                 <tr>  
                     <td width="30%"><label>Manche</label></td>  
                     <td width="70%">'.$row["manche"].' </td>  
                </tr>  
                ';  
                
                
      }  
      $output .= "</table></div>";  
      echo $output;  
 }  
 ?>