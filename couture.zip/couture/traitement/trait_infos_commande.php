<?php 
$code=$_GET['id'];
$tab=array();
$data=array();
$array=array();
$query = "SELECT * FROM commande WHERE code_commande ='{$code}'"; 
$sql=$conn->query($query);
$result=$sql->fetchAll();
foreach ($result as $key) {
$tab[]=$key;
}

$regis=$key['id_register'];

$queryy = "SELECT * FROM register WHERE id_register='{$regis}' "; 
$sqly=$conn->query($queryy);
$resulty=$sqly->fetchAll();
foreach ($resulty as $row) {
$array[]=$row;
}


$aa = "SELECT * FROM mensuration WHERE id_register='{$regis}' "; 
$reply=$conn->query($aa);
$slr=$reply->fetchAll();
foreach ($slr as $mow) {
$data[]=$mow;
}

 ?>