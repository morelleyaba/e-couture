 <?php 
 	 $array=array();
     $exep="En cour";
     $sql="SELECT * FROM commande,register WHERE statut='{$exep}' AND commande.id_register=register.id_register";
    $query=$conn->query($sql);  
    $result=$query->fetchAll();
    $count = 1;

  ?>
