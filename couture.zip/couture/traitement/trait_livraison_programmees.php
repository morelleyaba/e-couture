 <?php
// Build up DB connection including cofiguration file

if(isset($_POST['search'])){
    // Assign the fetched country to a variable and within the HTML tags with Boottrap class; list-group-item
    $response = "<ul class='list-group'><li class='list-group-item'>Code Non valide</li></ul>";

    $q = mysqli_real_escape_string($connect,$_POST["q"]);
    // mysql query to fetch the countries
    $query = "SELECT * FROM commande,register WHERE code_commande LIKE '$q%' AND commande.id_register=register.id_register"; 
    // execution of the query. Output a boolean value
    $res = mysqli_query($connect, $query);
    // Check if there are results matched
    if(mysqli_num_rows($res)>0){
        // Start the styling for fetch country list
        $response = "<ul class='list-group'>";
        // Display fetched all countries matched with the entered phrase
        while($row = mysqli_fetch_assoc($res)){
            // Concatenate the results to the previously started list
            $response .= "<li style='height: 60px;' class='list-group-item'>".$row["code_commande"]."</li>";
        }
        // End the styling for fetch country list
        $response .= "</ul>";

    }
    // Close results
    exit($response);


}

?>
