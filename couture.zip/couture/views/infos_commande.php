   


<!-- Page Container -->
<div class="w3-content w3-margin-top" style="max-width:1400px;">

  <!-- The Grid -->
  <div class="w3-row-padding">
  
    <!-- Left Column -->
    <div class="w3-third">
    
      <div class="w3-white w3-text-grey w3-card-4">
        <div class="w3-display-container">
          <img src="<?=$root_img?>article1.jpg" style="width:100%" alt="Avatar">
          <div class="w3-display-bottomleft w3-container w3-text-black">
            <h2>Robe 8000Fr</h2>
          </div>
        </div>
        <div class="w3-container">
          <B><!-- <p><i class="fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-teal"></i>Designer</p> -->
          <p>Nom : <?=$row['nom'] ?></p>
          <p><!-- <i class="fa fa-envelope fa-fw w3-margin-right w3-large w3-text-teal"></i> -->Ville : <?=$row['ville'] ?></p>
          <p><!-- <i class="fa fa-phone fa-fw w3-margin-right w3-large w3-text-teal"></i> -->Numero de telephone : <?=$row['numero'] ?></p>
          <p>Lieu de livraison : <?=$key['lieu_livraison'] ?></p>
          <hr>
</B>
          
        </div>
      </div><br>

    <!-- End Left Column -->
    </div>

    <!-- Right Column -->
    <div class="w3-twothird">
    
      <div class="w3-container w3-card w3-white w3-margin-bottom">
        <br>
      <!-- Toogle -->
      <?php include('traitement/trait_toogle.php') ?>
        <?php include('toogle.php') ?>
        <h2 class="w3-text-grey w3-padding-16">Code de Commande :  <?= $key['code_commande'] ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h2>
        <br>
        

        <div class="w3-container">
          <h5 class="w3-opacity"><b>Taille Standars "<?=$mow['taille'] ?> "</b></h5>
           <br>
        
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Date de commande</h6>
          <span class="w3-tag w3-teal w3-round"><?= $key['date_commande'] ?></span>
          <hr>
        
        </div>
        <div class="w3-container">
          <h5 class="w3-opacity"><b>Mensurations</b></h5>
          <h6 class="w3-text-teal"></h6>
<div class="col-lg-6">
          <table class="table table-bordered">
         <tr>
         <td>Epaule</td><td><?=$mow['epaule']?></td>
         </tr>

          <tr>
         <td>Poitrine     </td><td><?=$mow['poitrine']?></td>
         </tr>

         <tr>
         <td>Tour de Taille &nbsp;&nbsp;&nbsp;&nbsp;</td><td><?=$mow['tour_de_taille']?></td>
         </tr>

         <tr>
         <td>manche</td><td><?=$mow['manche']?></td>
         </tr>
          </table>
          
          </div>
          <hr>
        </div>
       </div>
      </div>

      

    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
  <!-- End Page Container -->
</div>

<footer class="w3-container w3-teal w3-center w3-margin-top">
  <p>E Couture</p>
  <i class="fa fa-facebook-official w3-hover-opacity"></i>
  <i class="fa fa-instagram w3-hover-opacity"></i>
  <i class="fa fa-snapchat w3-hover-opacity"></i>
  <i class="fa fa-pinterest-p w3-hover-opacity"></i>
  <i class="fa fa-twitter w3-hover-opacity"></i>
  <i class="fa fa-linkedin w3-hover-opacity"></i>
</footer>

</body>
</html>
