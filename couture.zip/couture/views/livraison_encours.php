  
<section> 
<div class="table-title">
<h3>Livraisons en cours</h3>
</div>
<br>
 <br>
 <div class="container-fluid">
<table class="table">
<thead>
<tr>
<th class="text-left">Code Commande</th>
<th class="text-left">Type Article</th>
<th class="text-left">Quantite</th>
<th class="text-left">Prix</th>
<th class="text-left">NOM</th>
<th class="text-left">Numero</th>
<th class="text-left">Mis a jour</th>


</tr>
</thead>
<tbody class="table-hover">
<?php foreach ($result as $row):?>   

<tr>
<td class="text-left"><?= $row['code_commande']?></td>
<td class="text-left"><?= $row['article']?></td>
<td class="text-left"><?= $row['quantité']?></></td>
<td class="text-left"><?= $row['prix']?></></td>
<td class="text-left"><?= $row['nom']?></></td>
<td class="text-left"><?= $row['numero']?></></td>
<td><a href="index.php?page=update&echec=<?=$row["code_commande"]; ?>"><button type="button" class="btn btn-danger" data-dismiss="modal">echec</button></a>
<a href="index.php?page=update&success=<?=$row["code_commande"]; ?>"><button type="button" class="btn btn-success" data-dismiss="modal">success</button></a>
</td>

</tr> 
<?php endforeach ?>
</tbody>
</table>
</div>
</section>
<?php
include('inc/footer.php');
?>