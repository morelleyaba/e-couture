<?php  

$exep="En Attente";
 $query = "SELECT * FROM commande,mensuration WHERE statut='{$exep}' AND commande.id_register=mensuration.id_register";  
 $result = mysqli_query($connect, $query);  
 ?>  
 
      <body>  
           <br /><br />  
           <div class="container" style="width:700px;">  
                <h3 align="center">Nouvelles Commandes</h3>  
                <br />  
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                               <th width="25%">Code Commande</th>  
                               <th width="35%">Type Article</th>  
                               <th width="10%">Quantité</th> 
                               <th width="10%">Mensuration</th>
                                
                          </tr>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          <tr>  
                               <td><?php echo $row["code_commande"]; ?></td>
                               <td><?php echo $row["article"]; ?></td>
                               <td><?php echo $row["quantité"]; ?></td>  
                               <td><input type="button" name="view" value="view" id="<?php echo $row["code_commande"]; ?>" class="btn btn-info btn-xs view_data" /></td> 

                               <td><a href="index.php?page=update&code=<?=$row["code_commande"]; ?>"><button type="button" class="btn btn-success" data-dismiss="modal">Valider</button></a></td>

               

                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">Mensurations Details</h4>  
                </div>  
                <div class="modal-body" id="employee_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var commande_value = $(this).attr("id");  
           $.ajax({  
                url:"traitement/trait_commande.php",  
                method:"post",  
                data:{commande_value:commande_value},  
                success:function(data){  
                     $('#employee_detail').html(data);  
                     $('#dataModal').modal("show");  
                }  
           });  
      });  
 });  
 </script>