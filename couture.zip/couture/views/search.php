   
    <div class="col-lg-12">
	    <div class="col-lg-3"></div>
	    <div class="col-lg-6">
			<table class="table table-bordered">

<?php
// Check if there are rows matched with the query
if($count>0)
{
    // Output the details within a table with Bootstrap styes
	while($data = mysqli_fetch_assoc($res)){

        echo '<tr>';
        echo "<td>".'Code'."</td>"."<td>".$data['code_commande']."</td>"; 
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Vetement'."</td>"."<td>".$data['article']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Nom Client'."</td>"."<td>".$data['nom']."  ".$data['prenom']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Numero'."</td>"."<td>".$data['numero']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Date'."</td>"."<td>".$data['date']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Quantite'."</td>"."<td>".$data['quantité']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Prix'."</td>"."<td>".$data['prix']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'statut'."</td>"."<td>".$data['statut']."</td>";
        echo '</tr>';

 		echo '</table>';
	}
}
// If there are no matching countries this will displayed in the browser
else {
	echo "No Data";
}

?><br>
<!-- Return button to the input page -->
               <center>
                    <a href="index.php?page=home" class="btn btn-default">Retour</a>
                </center>
		
        
	</div>
</body>
</html>
