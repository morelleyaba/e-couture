<?php 
 include('../inc/bd.php');

if (isset($_GET['code'])) {
	 $exep="En Cour";
	$code = $_GET['code'];
	$conn->query("UPDATE commande SET statut = '{$exep}' WHERE code_commande = '{$code}'");
	header('location: index.php?page=nouvelle_commande');
	}

	if (isset($_GET['echec'])) {
		 $exep="Echec";
	$echec = $_GET['echec'];
	$conn->query("UPDATE commande SET statut = '{$exep}' WHERE code_commande = '{$echec}'");
	header('location: index.php?page=livraison_encours');
	}

	if (isset($_GET['success'])) {
		 $exep="Success";
	$success = $_GET['success'];
	$conn->query("UPDATE commande SET statut = '{$exep}' WHERE code_commande = '{$success}'");
	header('location: index.php?page=livraison_encours');
	}
 ?>